
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { NgModule } from '@angular/core';

console.clear();

class Car {
  public static drive(speed: number): string;
  public static drive(speed: number, target: number): number[];
  public static drive(speed: number, target?: number): string | number[] {
    if (target) {
      const arr: number[] = [];
      
      for (let i = speed; i <= target; i++) {
        arr.push(i);
      }
      
      return arr;
    }

    return `Car is driving with ${speed} km/h.`;
  }
}

const speeds: number[] = Car.drive(100, 105);

console.log(Car.drive(100));

for (let i = 0; i < speeds.length; i++) {
  console.log(`Car is now driving with ${speeds[i]} km/h.`);
}
