import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { NgModule } from '@angular/core';

class Person {

 firstName: string;
 lastName: string;
 
 constructor (fName: string, lName: string) {
  
  this.firstName = fName;
  this.lastName = lName;
 }
 
 getFullName() {
  return `${firstName} ${lastName}`;
 }
}
class Employee extends Person {

 empID: string;
 designation: string;

 constructor (fName: string, lName: string,
     eID: string, desig: string) {
  
  super(fName, lName);
  
  this.empID = eID;
  this.designation = desig;
 }
 
 toString() {
  return `${empID} - ${firstName} ${lastName}
    => ${designation}`;
 }
}