import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { NgModule } from '@angular/core';

class Person{
    name:string
 
    eat():void{
        console.log(this.name+" eats when hungry.")
    }
}
 
class Student extends Person{
    
    rollnumber:number;
 
    
    constructor(rollnumber:number, name1:string){
        super(); 
        this.rollnumber = rollnumber
        this.name = name1
    }
 
    
    displayInformation():void{
        console.log("Name : "+this.name+", Roll Number : "+this.rollnumber)
    }
 
    
    eat():void{
        console.log(this.name+" eats during break.")
    }
}
 
var student1 = new Student(2, "Rohit")
 
student1.displayInformation()
student1.eat()